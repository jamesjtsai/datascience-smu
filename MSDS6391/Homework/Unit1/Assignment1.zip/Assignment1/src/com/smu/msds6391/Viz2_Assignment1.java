/* MSDS 6391
 * Assignment 1
 * 01/17/17
 * James Tsai, Wid Sogata
 */

package com.smu.msds6391;

import processing.core.*; 
import processing.data.*;
import java.util.ArrayList;

public class Viz2_Assignment1 extends PApplet{
 
ArrayList<Ball> balls;


public void setup() {
  
  PShape sphere;
  balls = new ArrayList<Ball>();
  Population top10 = new Population("top10.csv");
  top10.load(this);
  
  Table table = top10.retrieve();
  
  for (TableRow row: table.rows()) {
    // get image name
    String image = row.getString("country")+".png";
    //System.out.println(image);
    // population in thousands
    float pop = row.getFloat("population");
    // take population as volume, convert to radius
    float radius = pow((pop * 0.75f)/PI, 0.3333f);
    sphere = createShape(SPHERE, radius);
    Ball ball = new Ball(this, sphere, image, radius); 
    balls.add(ball);
  }
}

public void draw() {
  background(128, 128, 128);
  textSize(40);
 
  fill(160,160,160);
  rect (5,5,890,490);
  fill(162,62,62);
  text("Top 10 World Population", width/4, 50);
  // Display first row
  translate(-50, height/3);
  for (Ball b: balls) {
    if (balls.indexOf(b)<5) {
      translate(width/5.1f, 0);     
      pushMatrix();
      b.rotate(this);
      b.display(this);
      popMatrix();
    }
  }
  // Display second row
  translate(width/5.65f, height/3);
  for (Ball b: balls) {
    if (balls.indexOf(b)>=5) {
      translate(-width/5.2f, 0);
      pushMatrix();
      b.rotate(this);
      b.display(this);
      popMatrix();
    }
  }
}


public void settings() { size(900, 500, P3D); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#555555", "--stop-color=#cccccc", "com.smu.msds6391.Viz2_Assignment1" };
    if (passedArgs != null) {	
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
