package com.smu.msds6391;

import processing.data.*;
import processing.core.*;

public class Population {
  PApplet p;
  
  Population(String fn) {
  	 this.fn = fn;
  }
  // load table
  public void load(PApplet p) {
	this.p = p;
    table = p.loadTable(fn, "header");
    PApplet.println(table.getRowCount() + " total rows in table");
  }
  
  public Table retrieve() {
    return table;
  }
  
  String fn;
  Table table;
  
}
