package com.smu.msds6391;

import processing.core.*;

public class Ball {
   PApplet p;
	
  Ball(PShape sphere){
	 this.sphere = sphere;
  }
	
 Ball(PApplet p, PShape sphere, String flag, float radius) {
    this.p = p;
    this.radius = radius;
    this.sphere = sphere;
	System.out.println(flag);
	sphere.setTexture(p.loadImage(flag));
    sphere.setStroke(false);
  }
  
  public void display(PApplet p) {
    this.p = p;
	p.shape(sphere);
  }
  
  public void rotate(PApplet p) {
	this.p = p;  

    p.rotateY(p.frameCount*PApplet.PI/(radius*-1.5f));
    p.rotateZ(p.frameCount*PApplet.PI/(radius*2));
  }
  
  float radius;
  String flag;
  PShape sphere;

}
